document.addEventListener('DOMContentLoaded', function() {
    // Function to handle file input change
    function handleFileInput() {
        const fileInput = document.getElementById('plant_image');
        const previewImg = document.getElementById('upload_preview');
        const fileLabel = document.querySelector('.file-upload-label span');
        
        if (!fileInput || !previewImg) return;
        
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            
            if (file) {
                // Update label text
                if (fileLabel) {
                    fileLabel.textContent = file.name;
                }
                
                // Show image preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    previewImg.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                // Reset to default state
                if (fileLabel) {
                    fileLabel.textContent = 'Drag and drop your image or click to select';
                }
                previewImg.style.display = 'none';
            }
        });
    }
    
    // Function to handle drag and drop
    function handleDragAndDrop() {
        const dropArea = document.querySelector('.file-upload-label');
        const fileInput = document.getElementById('plant_image');
        
        if (!dropArea || !fileInput) return;
        
        // Prevent default behaviors for drag events
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        // Visual feedback when dragging over drop area
        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            dropArea.style.borderColor = 'var(--primary-light)';
            dropArea.style.backgroundColor = 'rgba(76, 175, 80, 0.1)';
        }
        
        function unhighlight() {
            dropArea.style.borderColor = 'var(--primary)';
            dropArea.style.backgroundColor = 'transparent';
        }
        
        // Handle dropped files
        dropArea.addEventListener('drop', handleDrop, false);
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            
            if (files.length) {
                fileInput.files = files;
                // Trigger change event manually
                const event = new Event('change');
                fileInput.dispatchEvent(event);
            }
        }
    }
    
    // Function to validate the form
    function validateForm() {
        const forms = document.querySelectorAll('form');
        
        forms.forEach(form => {
            form.addEventListener('submit', function(event) {
                // Get file input
                const fileInput = this.querySelector('input[type="file"]');
                if (fileInput && fileInput.files.length === 0) {
                    event.preventDefault();
                    alert('Please select an image file');
                    return false;
                }
                
                // Show loading indicator
                showLoading();
                return true;
            });
        });
    }
    
    // Initialize functions
    handleFileInput();
    handleDragAndDrop();
    validateForm();
});
