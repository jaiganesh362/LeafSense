import os
import uuid
from datetime import datetime
from flask import render_template, request, flash, redirect, url_for, jsonify, send_file
from werkzeug.utils import secure_filename

from models import db, PlantType, Disease, Treatment, CareRoutine, DiagnosisHistory, init_sample_data

from plant_disease_model import predict_disease
from pdf_generator import generate_diagnosis_pdf, generate_care_pdf
from utils import allowed_file


def init_routes(app):
    """Initialize the routes for the Flask application."""
    with app.app_context():
        init_sample_data()
        
    # Route handlers follow
    
    @app.route('/')
    def index():
        return render_template('index.html')
    
    @app.route('/diagnosis')
    def diagnosis():
        plant_types = PlantType.query.all()
        return render_template('diagnosis.html', plant_types=plant_types)
    
    @app.route('/care')
    def care():
        plant_types = PlantType.query.all()
        return render_template('care.html', plant_types=plant_types)
    
    @app.route('/api/plant-types')
    def get_plant_types():
        plant_types = PlantType.query.all()
        return jsonify([{'id': pt.id, 'name': pt.name} for pt in plant_types])
    
    @app.route('/upload/diagnosis', methods=['POST'])
    def upload_diagnosis():
        # Check if the post request has the file part
        if 'plant_image' not in request.files:
            flash('No file part', 'error')
            return redirect(request.url)
        
        file = request.files['plant_image']
        
        # If user does not select file, browser may submit an empty file
        if file.filename == '':
            flash('No selected file', 'error')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            # Generate a unique filename
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4().hex}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(file_path)
            
            # Get form data
            plant_type_id = request.form.get('plant_type')
            days_planting = request.form.get('days_planting')
            days_symptoms = request.form.get('days_symptoms')
            
            if days_planting == 'unknown':
                days_planting = None
            if days_symptoms == 'unknown':
                days_symptoms = None
            
            # Make prediction using the model
            plant_type = PlantType.query.get(plant_type_id)
            disease_id = predict_disease(file_path, plant_type_id)
            disease = Disease.query.get(disease_id)
            
            # Save diagnosis to database
            diagnosis = DiagnosisHistory(
                plant_type_id=plant_type_id,
                disease_id=disease_id,
                image_path=file_path,
                days_since_planting=days_planting,
                days_since_symptoms=days_symptoms,
                diagnosis_date=datetime.utcnow()
            )
            db.session.add(diagnosis)
            db.session.commit()
            
            # Generate PDF report
            treatments = Treatment.query.filter_by(disease_id=disease_id).all()
            pdf_path = generate_diagnosis_pdf(diagnosis, disease, treatments, plant_type)
            
            # Update diagnosis with PDF path
            diagnosis.pdf_report_path = pdf_path
            db.session.commit()
            
            return redirect(url_for('diagnosis_result', diagnosis_id=diagnosis.id))
        
        flash('File type not allowed', 'error')
        return redirect(request.url)
    
    @app.route('/upload/care', methods=['POST'])
    def upload_care():
        # Check if the post request has the file part
        if 'plant_image' not in request.files:
            flash('No file part', 'error')
            return redirect(request.url)
        
        file = request.files['plant_image']
        
        # If user does not select file, browser may submit an empty file
        if file.filename == '':
            flash('No selected file', 'error')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            # Generate a unique filename
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4().hex}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(file_path)
            
            # Get form data
            plant_type_id = request.form.get('plant_type')
            plant_age = request.form.get('plant_age')
            
            if plant_age == 'unknown':
                plant_age = 30  # Default to 30 days if unknown
            
            # Find appropriate care routine
            plant_type = PlantType.query.get(plant_type_id)
            
            # Get current season (simplified)
            current_month = datetime.now().month
            if 3 <= current_month <= 5:
                season = "Spring"
            elif 6 <= current_month <= 8:
                season = "Summer"
            elif 9 <= current_month <= 11:
                season = "Fall"
            else:
                season = "Winter"
            
            # Get care routine based on age and season
            care_routine = CareRoutine.query.filter(
                CareRoutine.plant_type_id == plant_type_id,
                CareRoutine.age_range_min <= plant_age,
                CareRoutine.age_range_max >= plant_age,
                CareRoutine.season == season
            ).first()
            
            # If specific routine not found, get a generic one for the plant type
            if not care_routine:
                care_routine = CareRoutine.query.filter(
                    CareRoutine.plant_type_id == plant_type_id
                ).first()
            
            # If still no care routine, create a basic default one
            if not care_routine:
                care_routine = CareRoutine(
                    plant_type_id=plant_type_id,
                    age_range_min=0,
                    age_range_max=1000,
                    season="Any",
                    watering_frequency="Regular",
                    watering_amount="Moderate",
                    fertilizer_type="General purpose",
                    fertilizer_frequency="Monthly",
                    special_care="Keep soil moist but not waterlogged. Ensure adequate sunlight.",
                    plant_type=plant_type
                )
            
            # Generate PDF with care routine
            pdf_path = generate_care_pdf(plant_type, care_routine, file_path, plant_age)
            
            return redirect(url_for('care_result', plant_type_id=plant_type_id, 
                                  pdf_path=os.path.basename(pdf_path)))
    
    @app.route('/diagnosis/result/<int:diagnosis_id>')
    def diagnosis_result(diagnosis_id):
        diagnosis = DiagnosisHistory.query.get_or_404(diagnosis_id)
        disease = Disease.query.get(diagnosis.disease_id)
        treatments = Treatment.query.filter_by(disease_id=diagnosis.disease_id).all()
        plant_type = PlantType.query.get(diagnosis.plant_type_id)
        
        return render_template('results.html', 
                             diagnosis=diagnosis,
                             disease=disease,
                             treatments=treatments,
                             plant_type=plant_type,
                             result_type='diagnosis')
    
    @app.route('/care/result/<int:plant_type_id>/<path:pdf_path>')
    def care_result(plant_type_id, pdf_path):
        plant_type = PlantType.query.get_or_404(plant_type_id)
        full_pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], pdf_path)
        
        return render_template('results.html',
                             plant_type=plant_type,
                             pdf_path=pdf_path,
                             result_type='care')
    
    @app.route('/download/<path:filename>')
    def download_file(filename):
        return send_file(os.path.join(app.config['UPLOAD_FOLDER'], filename), as_attachment=True)
