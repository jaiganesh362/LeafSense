import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import EfficientNetB0 # type: ignore
from tensorflow.keras.preprocessing.image import ImageDataGenerator # type: ignore
from tensorflow.keras.models import Model# type: ignore
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout # type: ignore
from tensorflow.keras.optimizers import Adam # type: ignore
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau # type: ignore

# Constants
IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 10
NUM_CLASSES = 38  
def create_model():
    """
    Create an EfficientNetB0 model for plant disease classification.
    
    The model is based on the EfficientNetB0 architecture, pre-trained on ImageNet,
    with custom classification layers added for the specific plant disease classes.
    """
    # Base model with pre-trained weights
    base_model = EfficientNetB0(
        weights='imagenet',
        include_top=False,
        input_shape=(IMG_SIZE, IMG_SIZE, 3)
    )
    
    # Freeze base model layers
    for layer in base_model.layers:
        layer.trainable = False
    
    # Add custom layers for classification
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(1024, activation='relu')(x)
    x = Dropout(0.2)(x)
    x = Dense(512, activation='relu')(x)
    x = Dropout(0.2)(x)
    predictions = Dense(NUM_CLASSES, activation='softmax')(x)
    
    # Create the model
    model = Model(inputs=base_model.input, outputs=predictions)
    
    # Compile model
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def prepare_data_generators(data_dir):
    """
    Prepare data generators for training, validation, and testing.
    
    Args:
        data_dir: The directory containing the plant disease images
                 (expected to have train, val, and test subdirectories)
    
    Returns:
        train_generator, val_generator, test_generator
    """
    # Data augmentation for training
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest'
    )
    
    # Only rescaling for validation and test
    val_datagen = ImageDataGenerator(rescale=1./255)
    test_datagen = ImageDataGenerator(rescale=1./255)
    
    # Create generators
    train_generator = train_datagen.flow_from_directory(
        os.path.join(data_dir, 'train'),
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical'
    )
    
    val_generator = val_datagen.flow_from_directory(
        os.path.join(data_dir, 'val'),
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical'
    )
    
    test_generator = test_datagen.flow_from_directory(
        os.path.join(data_dir, 'test'),
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        shuffle=False
    )
    
    return train_generator, val_generator, test_generator

def train_model(data_dir, model_save_path):
    """
    Train the EfficientNetB0 model on the plant disease dataset.
    
    Args:
        data_dir: Directory containing plant disease dataset with train/val/test subdirectories
        model_save_path: Path to save the trained model
    
    Returns:
        Trained model and training history
    """
    # Create model architecture
    model = create_model()
    
    # Prepare data
    train_generator, val_generator, test_generator = prepare_data_generators(data_dir)
    
    # Setup callbacks
    checkpoint = ModelCheckpoint(
        model_save_path,
        monitor='val_accuracy',
        verbose=1,
        save_best_only=True,
        mode='max'
    )
    
    early_stopping = EarlyStopping(
        monitor='val_loss',
        patience=7,
        restore_best_weights=True
    )
    
    reduce_lr = ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.2,
        patience=3,
        min_lr=1e-6
    )
    
    callbacks = [checkpoint, early_stopping, reduce_lr]
    
    # Train the model (phase 1 - feature extraction)
    history = model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // BATCH_SIZE,
        validation_data=val_generator,
        validation_steps=val_generator.samples // BATCH_SIZE,
        epochs=10,
        callbacks=callbacks
    )
    
    # Fine tuning - unfreeze some top layers of the base model
    for layer in model.layers[-20:]:
        layer.trainable = True
    
    # Recompile model with a lower learning rate for fine-tuning
    model.compile(
        optimizer=Adam(learning_rate=0.0001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    # Train the model (phase 2 - fine tuning)
    fine_tune_history = model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // BATCH_SIZE,
        validation_data=val_generator,
        validation_steps=val_generator.samples // BATCH_SIZE,
        epochs=EPOCHS,
        callbacks=callbacks,
        initial_epoch=history.epoch[-1]
    )
    
    # Evaluate the model on the test set
    test_loss, test_accuracy = model.evaluate(test_generator)
    print(f"Test accuracy: {test_accuracy:.4f}")
    
    # Save the class indices mapping
    class_indices = train_generator.class_indices
    class_indices_path = os.path.splitext(model_save_path)[0] + "_classes.npy"
    np.save(class_indices_path, class_indices)
    
    print(f"Model saved to {model_save_path}")
    print(f"Class indices saved to {class_indices_path}")
    
    return model, history

def prepare_kaggle_dataset(kaggle_dataset_path, output_dir):
    """
    Prepare the Kaggle plant disease dataset for training.
    
    This function organizes the dataset into train/val/test splits
    if it hasn't been organized already.
    
    Args:
        kaggle_dataset_path: Path to the downloaded Kaggle dataset
        output_dir: Directory to save the organized dataset
    """
    import shutil
    from sklearn.model_selection import train_test_split
    
    # Create output directories
    os.makedirs(os.path.join(output_dir, 'train'), exist_ok=True)
    os.makedirs(os.path.join(output_dir, 'val'), exist_ok=True)
    os.makedirs(os.path.join(output_dir, 'test'), exist_ok=True)
    
    # Check if the dataset is already organized
    if any(os.listdir(os.path.join(output_dir, 'train'))):
        print("Dataset already prepared. Skipping preparation.")
        return
    
    # Get all class directories
    class_dirs = [d for d in os.listdir(kaggle_dataset_path) 
                 if os.path.isdir(os.path.join(kaggle_dataset_path, d))]
    
    for class_dir in class_dirs:
        # Create class directories in train/val/test
        os.makedirs(os.path.join(output_dir, 'train', class_dir), exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'val', class_dir), exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'test', class_dir), exist_ok=True)
        
        # Get all images in the class directory
        img_files = [f for f in os.listdir(os.path.join(kaggle_dataset_path, class_dir))
                    if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        
        # Split into train, val, test (70%, 15%, 15%)
        train_files, test_val_files = train_test_split(img_files, test_size=0.3, random_state=42)
        val_files, test_files = train_test_split(test_val_files, test_size=0.5, random_state=42)
        
        # Copy files to their respective directories
        for file in train_files:
            src = os.path.join(kaggle_dataset_path, class_dir, file)
            dst = os.path.join(output_dir, 'train', class_dir, file)
            shutil.copy(src, dst)
        
        for file in val_files:
            src = os.path.join(kaggle_dataset_path, class_dir, file)
            dst = os.path.join(output_dir, 'val', class_dir, file)
            shutil.copy(src, dst)
        
        for file in test_files:
            src = os.path.join(kaggle_dataset_path, class_dir, file)
            dst = os.path.join(output_dir, 'test', class_dir, file)
            shutil.copy(src, dst)
    
    print("Dataset preparation complete.")

def main():
    """
    Main function to run the training process.
    
    This function should be run after downloading the Kaggle plant disease dataset.
    """
    # Define paths
    kaggle_dataset_path = "path/to/kaggle/plant-disease"  # Update this path
    prepared_data_dir = "data/prepared_plant_disease"
    model_save_path = "models/plant_disease_efficientnetb0.h5"
    
    # Create directories
    os.makedirs(os.path.dirname(prepared_data_dir), exist_ok=True)
    os.makedirs(os.path.dirname(model_save_path), exist_ok=True)
    
    # Prepare dataset (run this if you have the raw Kaggle dataset)
    # prepare_kaggle_dataset(kaggle_dataset_path, prepared_data_dir)
    
    # Train the model
    train_model(prepared_data_dir, model_save_path)

if __name__ == "__main__":
    main()