import os
import kaggle
import zipfile
import argparse

def download_dataset():
    """
    Download the Plant Disease dataset from Kaggle.
    
    This requires Kaggle API credentials to be set up.
    You can set up your Kaggle API token by:
    1. Go to your Kaggle account settings
    2. Click on "Create New API Token" to download kaggle.json
    3. Place the kaggle.json file in ~/.kaggle/ or set the KAGGLE_CONFIG_DIR environment variable
    """
    print("Downloading Plant Disease dataset from Kaggle...")
    
    # Create directories
    os.makedirs('data', exist_ok=True)
    
    # Download the dataset
    kaggle.api.dataset_download_files(
        'emmarex/plantdisease',
        path='data',
        unzip=True
    )
    
    print("Dataset downloaded and extracted to the 'data' directory.")

def extract_dataset(zip_path, extract_to):
    """
    Extract the dataset from a zip file.
    
    Args:
        zip_path: Path to the zip file
        extract_to: Directory to extract the files to
    """
    print(f"Extracting {zip_path} to {extract_to}...")
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    
    print("Extraction complete.")

def main():
    parser = argparse.ArgumentParser(description='Download and extract the Plant Disease dataset from Kaggle.')
    parser.add_argument('--manual-path', type=str, help='Path to manually downloaded dataset zip file')
    parser.add_argument('--extract-to', type=str, default='data', help='Directory to extract the dataset to')
    
    args = parser.parse_args()
    
    if args.manual_path:
        extract_dataset(args.manual_path, args.extract_to)
    else:
        download_dataset()

if __name__ == "__main__":
    main()