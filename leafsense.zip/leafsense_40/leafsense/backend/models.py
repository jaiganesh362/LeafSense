from extension import db 
from datetime import datetime

# Plant species and varieties
class PlantType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    care_instructions = db.Column(db.Text)
    
    def __repr__(self):
        return f'<PlantType {self.name}>'

# Disease information
class Disease(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    cause = db.Column(db.Text)
    symptoms = db.Column(db.Text)
    plant_type_id = db.Column(db.Integer, db.ForeignKey('plant_type.id'))
    plant_type = db.relationship('PlantType', backref='diseases')
    
    def __repr__(self):
        return f'<Disease {self.name}>'

# Treatment recommendations
class Treatment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    disease_id = db.Column(db.Integer, db.ForeignKey('disease.id'), nullable=False)
    medicine_name = db.Column(db.String(100))
    dosage = db.Column(db.String(100))
    application_method = db.Column(db.Text)
    preventive_measures = db.Column(db.Text)
    disease = db.relationship('Disease', backref='treatments')
    
    def __repr__(self):
        return f'<Treatment for {self.disease.name} - {self.medicine_name}>'

# Care routines for plants
class CareRoutine(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plant_type_id = db.Column(db.Integer, db.ForeignKey('plant_type.id'), nullable=False)
    age_range_min = db.Column(db.Integer)  # Plant age in days
    age_range_max = db.Column(db.Integer)
    season = db.Column(db.String(20))
    watering_frequency = db.Column(db.String(50))
    watering_amount = db.Column(db.String(50))
    fertilizer_type = db.Column(db.String(100))
    fertilizer_frequency = db.Column(db.String(50))
    special_care = db.Column(db.Text)
    plant_type = db.relationship('PlantType', backref='care_routines')
    
    def __repr__(self):
        return f'<CareRoutine for {self.plant_type.name} - age: {self.age_range_min}-{self.age_range_max} days, season: {self.season}>'

# Store diagnosis history
class DiagnosisHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plant_type_id = db.Column(db.Integer, db.ForeignKey('plant_type.id'))
    disease_id = db.Column(db.Integer, db.ForeignKey('disease.id'))
    image_path = db.Column(db.String(255))
    days_since_planting = db.Column(db.Integer, nullable=True)
    days_since_symptoms = db.Column(db.Integer, nullable=True)
    diagnosis_date = db.Column(db.DateTime, default=datetime.utcnow)
    pdf_report_path = db.Column(db.String(255), nullable=True)
    
    plant_type = db.relationship('PlantType', backref='diagnoses')
    disease = db.relationship('Disease', backref='diagnoses')
    
    def __repr__(self):
        return f'<Diagnosis #{self.id} - {self.diagnosis_date}>'

# Initialize database with some sample data
def init_sample_data():
    # Check if data exists first
    if PlantType.query.count() > 0:
        return
    
    # Add plant types
    tomato = PlantType(name="Tomato", description="Common garden vegetable with red fruits",
                     care_instructions="Plant in well-draining soil with full sun exposure.")
    potato = PlantType(name="Potato", description="Root vegetable grown underground",
                     care_instructions="Plant in loose soil and hill as plants grow.")
    apple = PlantType(name="Apple", description="Common fruit tree with sweet fruits",
                    care_instructions="Requires regular pruning and full sun.")
    corn = PlantType(name="Corn", description="Tall grass producing ears with kernels",
                   care_instructions="Plant in blocks rather than rows for better pollination.")
    bell_pepper = PlantType(name="Bell Pepper", description="Sweet, bell-shaped vegetable",
                          care_instructions="Needs warm soil and consistent watering.")
    
    db.session.add_all([tomato, potato, apple, corn, bell_pepper])
    db.session.commit()
    
    # Add diseases
    diseases = [
        Disease(name="Early Blight", description="Fungal disease affecting leaves, stems and fruits",
               cause="Fungus Alternaria solani", symptoms="Dark spots with concentric rings on lower leaves",
               plant_type=tomato),
        Disease(name="Late Blight", description="Serious fungal disease that can kill plants quickly",
               cause="Phytophthora infestans", symptoms="Water-soaked spots on leaves, white fuzzy growth",
               plant_type=tomato),
        Disease(name="Potato Scab", description="Common disease causing corky lesions",
               cause="Streptomyces bacteria", symptoms="Rough, corky patches on tuber surface",
               plant_type=potato),
        Disease(name="Apple Scab", description="Fungal disease causing dark lesions",
               cause="Venturia inaequalis", symptoms="Olive-green to brown spots on leaves and fruits",
               plant_type=apple),
        Disease(name="Corn Rust", description="Fungal disease with orange pustules",
               cause="Puccinia sorghi", symptoms="Small, orange-brown pustules on leaves",
               plant_type=corn)
    ]
    db.session.add_all(diseases)
    db.session.commit()
    
    # Add treatments
    treatments = [
        Treatment(disease=diseases[0], medicine_name="Copper Fungicide", 
                dosage="2-4 tablespoons per gallon of water", 
                application_method="Spray on leaves every 7-10 days",
                preventive_measures="Rotate crops, space plants for good airflow, mulch around plants"),
        Treatment(disease=diseases[1], medicine_name="Chlorothalonil", 
                dosage="2 teaspoons per gallon of water", 
                application_method="Apply at first sign of disease and repeat weekly",
                preventive_measures="Remove infected plants, avoid overhead watering"),
        Treatment(disease=diseases[2], medicine_name="Soil Sulfur", 
                dosage="1 pound per 100 square feet", 
                application_method="Mix into soil before planting",
                preventive_measures="Maintain soil pH below 5.2, use resistant varieties"),
        Treatment(disease=diseases[3], medicine_name="Myclobutanil", 
                dosage="Follow package instructions", 
                application_method="Spray trees at green tip stage and repeat as directed",
                preventive_measures="Rake and destroy fallen leaves, prune for good air circulation"),
        Treatment(disease=diseases[4], medicine_name="Propiconazole", 
                dosage="1-2 ounces per gallon of water", 
                application_method="Apply at first sign of pustules",
                preventive_measures="Plant resistant varieties, rotate corn plantings")
    ]
    db.session.add_all(treatments)
    
    # Add care routines
    care_routines = [
        CareRoutine(plant_type=tomato, age_range_min=0, age_range_max=30, season="Summer",
                  watering_frequency="Daily", watering_amount="1 inch per week",
                  fertilizer_type="Balanced (10-10-10)", fertilizer_frequency="Every 2 weeks",
                  special_care="Stake or cage plants when they reach 12 inches tall"),
        CareRoutine(plant_type=tomato, age_range_min=31, age_range_max=90, season="Summer",
                  watering_frequency="Every other day", watering_amount="1-2 inches per week",
                  fertilizer_type="High in phosphorus (5-10-5)", fertilizer_frequency="Every 3 weeks",
                  special_care="Prune suckers for indeterminate varieties"),
        CareRoutine(plant_type=potato, age_range_min=0, age_range_max=60, season="Spring",
                  watering_frequency="Every 4-5 days", watering_amount="1-2 inches per week",
                  fertilizer_type="Low nitrogen (5-10-10)", fertilizer_frequency="At planting time",
                  special_care="Hill soil around stems as plants grow"),
        CareRoutine(plant_type=apple, age_range_min=0, age_range_max=365, season="Spring",
                  watering_frequency="Weekly", watering_amount="Deeply, especially during fruit development",
                  fertilizer_type="Balanced (10-10-10)", fertilizer_frequency="Early spring and fall",
                  special_care="Prune in late winter when tree is dormant"),
        CareRoutine(plant_type=corn, age_range_min=0, age_range_max=100, season="Summer",
                  watering_frequency="Every 3-4 days", watering_amount="1-2 inches per week",
                  fertilizer_type="High nitrogen (16-4-8)", fertilizer_frequency="When plants are knee high",
                  special_care="Side-dress with nitrogen when plants are 12 inches tall")
    ]
    db.session.add_all(care_routines)
    db.session.commit()
