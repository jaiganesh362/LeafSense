import os
import io
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from flask import current_app

def generate_diagnosis_pdf(diagnosis, disease, treatments, plant_type):
    buffer = io.BytesIO()
    pdf_filename = f"diagnosis_report_{diagnosis.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf_path = os.path.join(current_app.config['UPLOAD_FOLDER'], pdf_filename)
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=letter,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=72
    )
    
    styles = getSampleStyleSheet()
    title_style = styles["Heading1"]
    title_style.textColor = colors.darkgreen
    
    heading_style = styles["Heading2"]
    heading_style.textColor = colors.darkgreen
    
    subheading_style = styles["Heading3"]
    subheading_style.textColor = colors.darkgreen
    
    normal_style = styles["Normal"]

    care_style = ParagraphStyle(
        name='CareStyle',
        parent=styles['Normal'],
        textColor=colors.black,
        fontSize=10,
        leading=14,
        spaceAfter=10,
        bulletIndent=20,
        leftIndent=20
    )
    
    # Create the story (content) for the PDF
    story = []
    
    # Add title
    story.append(Paragraph("Plant Disease Diagnosis Report", title_style))
    story.append(Spacer(1, 0.25*inch))
    
    # Add date
    story.append(Paragraph(f"Date: {diagnosis.diagnosis_date.strftime('%B %d, %Y')}", normal_style))
    story.append(Spacer(1, 0.25*inch))
    
    # Add plant image
    if os.path.exists(diagnosis.image_path):
        img = Image(diagnosis.image_path, width=4*inch, height=3*inch)
        story.append(img)
        story.append(Spacer(1, 0.25*inch))
    
    # Plant information
    story.append(Paragraph("Plant Information", heading_style))
    story.append(Paragraph(f"Plant Type: {plant_type.name}", normal_style))
    
    if diagnosis.days_since_planting:
        story.append(Paragraph(f"Age: {diagnosis.days_since_planting} days", normal_style))
    
    if diagnosis.days_since_symptoms:
        story.append(Paragraph(f"Days Since Symptoms Appeared: {diagnosis.days_since_symptoms}", normal_style))
    
    story.append(Spacer(1, 0.25*inch))
    
    # Diagnosis
    story.append(Paragraph("Diagnosis", heading_style))
    story.append(Paragraph(f"Disease: {disease.name}", subheading_style))
    story.append(Paragraph(f"Description: {disease.description}", normal_style))
    story.append(Paragraph(f"Cause: {disease.cause}", normal_style))
    story.append(Paragraph(f"Symptoms: {disease.symptoms}", normal_style))
    story.append(Spacer(1, 0.25*inch))
    
    # Treatments
    story.append(Paragraph("Treatment Recommendations", heading_style))
    
    for treatment in treatments:
        story.append(Paragraph(f"Medicine: {treatment.medicine_name}", subheading_style))
        story.append(Paragraph(f"Dosage: {treatment.dosage}", normal_style))
        story.append(Paragraph(f"Application Method: {treatment.application_method}", normal_style))
        story.append(Spacer(1, 0.15*inch))
    
    # Preventive measures
    story.append(Paragraph("Preventive Measures", heading_style))
    for treatment in treatments:
        if treatment.preventive_measures:
            for measure in treatment.preventive_measures.split(','):
                story.append(Paragraph(f"• {measure.strip()}", care_style))
    
    # Long-term care
    story.append(Paragraph("Long-term Care Tips", heading_style))
    if plant_type.care_instructions:
        for instruction in plant_type.care_instructions.split('.'):
            if instruction.strip():
                story.append(Paragraph(f"• {instruction.strip()}.", care_style))
    
    # Build the PDF
    doc.build(story)
    
    return pdf_path

def generate_care_pdf(plant_type, care_routine, image_path, plant_age):
    """Generate a PDF report for plant care routine."""
    # Create the PDF filename
    pdf_filename = f"care_routine_{plant_type.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf_path = os.path.join(current_app.config['UPLOAD_FOLDER'], pdf_filename)
    
    # Create the PDF with ReportLab
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=letter,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=72
    )
    
    # Create styles
    styles = getSampleStyleSheet()
    title_style = styles["Heading1"]
    title_style.textColor = colors.darkgreen
    
    heading_style = styles["Heading2"]
    heading_style.textColor = colors.darkgreen
    
    subheading_style = styles["Heading3"]
    subheading_style.textColor = colors.darkgreen
    
    normal_style = styles["Normal"]
    
    # Create custom style for care schedule
    schedule_style = ParagraphStyle(
        name='ScheduleStyle',
        parent=styles['Normal'],
        textColor=colors.black,
        fontSize=10,
        leading=14,
        spaceAfter=10,
        bulletIndent=20,
        leftIndent=20
    )
    
    # Create the story (content) for the PDF
    story = []
    
    # Add title
    story.append(Paragraph("Plant Care Routine", title_style))
    story.append(Spacer(1, 0.25*inch))
    
    # Add date
    story.append(Paragraph(f"Date: {datetime.now().strftime('%B %d, %Y')}", normal_style))
    story.append(Spacer(1, 0.25*inch))
    
    # Add plant image
    if os.path.exists(image_path):
        img = Image(image_path, width=4*inch, height=3*inch)
        story.append(img)
        story.append(Spacer(1, 0.25*inch))
    
    # Plant information
    story.append(Paragraph("Plant Information", heading_style))
    story.append(Paragraph(f"Plant Type: {plant_type.name}", normal_style))
    story.append(Paragraph(f"Age: {plant_age} days", normal_style))
    story.append(Paragraph(f"Season: {care_routine.season}", normal_style))
    story.append(Spacer(1, 0.25*inch))
    
    # Care information
    story.append(Paragraph("Daily Care Schedule", heading_style))
    
    # Morning care
    story.append(Paragraph("Morning (6 AM - 10 AM)", subheading_style))
    story.append(Paragraph(f"• Watering: {care_routine.watering_amount} of water {care_routine.watering_frequency}", schedule_style))
    story.append(Paragraph("• Check soil moisture before watering", schedule_style))
    story.append(Paragraph("• Inspect for pests or disease symptoms", schedule_style))
    story.append(Spacer(1, 0.15*inch))
    
    # Mid-day care
    story.append(Paragraph("Mid-day (11 AM - 3 PM)", subheading_style))
    story.append(Paragraph("• Avoid watering during this time to prevent leaf burn", schedule_style))
    story.append(Paragraph("• Provide shade if extreme heat is expected", schedule_style))
    story.append(Spacer(1, 0.15*inch))
    
    # Evening care
    story.append(Paragraph("Evening (4 PM - 7 PM)", subheading_style))
    story.append(Paragraph("• Light watering if soil is dry (not on leaves)", schedule_style))
    if care_routine.fertilizer_type:
        story.append(Paragraph(f"• Apply {care_routine.fertilizer_type} fertilizer {care_routine.fertilizer_frequency}", schedule_style))
    story.append(Spacer(1, 0.15*inch))
    
    # Weekly care schedule
    story.append(Paragraph("Weekly Care Tasks", heading_style))
    
    # Create a table for weekly tasks
    data = [
        ["Day", "Task"],
        ["Monday", "Inspect plant for pests and disease"],
        ["Wednesday", f"Apply {care_routine.fertilizer_type} if scheduled"],
        ["Friday", "Prune dead or yellowing leaves"],
        ["Sunday", "Deep watering to encourage root growth"]
    ]
    
    table = Table(data, colWidths=[1.5*inch, 4*inch])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (1, 0), colors.darkgreen),
        ('TEXTCOLOR', (0, 0), (1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(table)
    story.append(Spacer(1, 0.25*inch))
    
    # Special care instructions
    story.append(Paragraph("Special Care Instructions", heading_style))
    if care_routine.special_care:
        for instruction in care_routine.special_care.split('.'):
            if instruction.strip():
                story.append(Paragraph(f"• {instruction.strip()}.", schedule_style))
    
    # General plant care tips
    story.append(Paragraph("General Care Tips", heading_style))
    if plant_type.care_instructions:
        for instruction in plant_type.care_instructions.split('.'):
            if instruction.strip():
                story.append(Paragraph(f"• {instruction.strip()}.", schedule_style))
    
    # Build the PDF
    doc.build(story)
    
    return pdf_path
