import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import metrics
from download_dataset import download_dataset

pathfile = 'data'

df = pd.DataFrame(pathfile)

df['plant_type'] = df['plant_type'].astype('category').cat.codes  
df['weather'] = df['weather'].astype('category').cat.codes    
features = ['soil_moisture', 'temperature', 'plant_type', 'weather', 'days_since_last_water']
X = df[features]
y = df['should_water']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)

model = DecisionTreeClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
print("Accuracy:", metrics.accuracy_score(y_test, y_pred))

def predict_watering(soil_moisture, temperature, plant_type, weather, days_since_last_water):
    # Encode plant_type and weather to match training data encoding
    plant_map = {'cactus': 0, 'rose': 1, 'tomato': 2}
    weather_map = {'cloudy': 0, 'rainy': 1, 'sunny': 2}

    input_data = [[
        soil_moisture,
        temperature,
        plant_map.get(plant_type, 0),
        weather_map.get(weather, 0),
        days_since_last_water
    ]]

    prediction = model.predict(input_data)
    return "Water the plant" if prediction[0] == 1 else "Do not water the plant"

# Example usage
print(predict_watering(28, 33, 'rose', 'sunny', 3))  # Try with different inputs
