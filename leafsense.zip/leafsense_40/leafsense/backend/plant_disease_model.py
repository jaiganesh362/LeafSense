import os
import random
import numpy as np
from PIL import Image

# Global variables to store the model and class indices
model = None
class_indices = None
class_mapping = None

def load_model():
    """
    Load the trained EfficientNetB0 model for plant disease prediction.
    
    This function tries to load the trained model if it exists.
    If the model file doesn't exist, it will fallback to using a simulated approach.
    
    Returns:
        Either the loaded model or a string indicating simulation mode
    """
    global model, class_indices, class_mapping
    
    model_path = os.path.join('models', 'plant_disease_efficientnetb0.h5')
    classes_path = os.path.join('models', 'plant_disease_efficientnetb0_classes.npy')
    
    # Check if the model file exists
    if os.path.exists(model_path) and os.path.exists(classes_path):
        try:
            import tensorflow as tf
            # Load the trained model
            model = tf.keras.models.load_model(model_path)
            # Load class indices
            class_indices = np.load(classes_path, allow_pickle=True).item()
            # Invert the dictionary to map indices to class names
            class_mapping = {v: k for k, v in class_indices.items()}
            print("Loaded plant disease model successfully.")
            return model
        except Exception as e:
            print(f"Error loading model: {e}")
            print("Falling back to simulation mode.")
            return "simulated_model"
    else:
        print("Model files not found. Using simulation mode.")
        return "simulated_model"

def preprocess_image(img_path):
    """
    Preprocess an image for model prediction.
    
    This function handles both real model preprocessing and simulation mode.
    
    Args:
        img_path: Path to the image file
        
    Returns:
        Preprocessed image data or a boolean indicating success in simulation mode
    """
    try:
        # Open and validate the image
        img = Image.open(img_path)
        
        # If we have a real model loaded, use TensorFlow preprocessing
        if model is not None and model != "simulated_model":
            try:
                import tensorflow as tf
                
                # Resize to the model's expected input size
                img = img.resize((224, 224))
                
                # Convert to numpy array and expand dimensions
                img_array = np.array(img)
                img_array = np.expand_dims(img_array, axis=0)
                
                # Normalize pixel values
                img_array = img_array / 255.0
                
                return img_array
            except Exception as e:
                print(f"Error in TensorFlow preprocessing: {e}")
                # Fallback to simulation mode
                img.thumbnail((224, 224))
                return True
        else:
            # Simulation mode
            img.thumbnail((224, 224))
            return True
            
    except Exception as e:
        print(f"Error processing image: {e}")
        return False

def predict_disease(image_path, plant_type_id):
    """
    Predict the plant disease from the image.
    
    This function uses the trained EfficientNetB0 model if available,
    or falls back to a simulated approach if the model is not available.
    
    Args:
        image_path: Path to the uploaded plant image
        plant_type_id: ID of the plant type from the database
        
    Returns:
        The disease ID to use for the diagnosis
    """
    global model, class_mapping
    
    # If model hasn't been loaded yet, load it now
    if model is None:
        load_model()
    
    # If we have a real model (not the simulation placeholder)
    if model is not None and model != "simulated_model":
        try:
            # Preprocess the image
            preprocessed_img = preprocess_image(image_path)
            
            # Make prediction
            predictions = model.predict(preprocessed_img)
            predicted_class_idx = np.argmax(predictions, axis=1)[0]
            
            # Get the class name from the index
            predicted_class_name = class_mapping.get(predicted_class_idx, 'Unknown')
            print(f"Model predicted class: {predicted_class_name}")
            
            # Map the predicted class to the appropriate disease in our database
            # This would require a mapping from model prediction classes to database disease IDs
            # For now, we'll use the simulation mapping as a fallback
            
            # Simplified mapping from predicted class name to disease_id
            # In a real implementation, this would be more sophisticated
            disease_name_map = {
                'Tomato_Early_blight': 1,
                'Tomato_Late_blight': 2,
                'Potato_Early_blight': 3,
                'Apple_scab': 4,
                'Corn_Common_rust': 5
            }
            
            # Try to map the predicted class name to a disease ID
            for class_name, disease_id in disease_name_map.items():
                if class_name.lower() in predicted_class_name.lower():
                    return disease_id
            
            # If no specific mapping found, use the simulation fallback
            print("No direct mapping found for prediction, using plant type fallback")
        except Exception as e:
            print(f"Error making prediction with model: {e}")
            print("Falling back to simulation mode")
    
    # Simulation fallback - map plant type ID to disease ID
    plant_to_disease_map = {
        1: 1,  # Tomato -> Early Blight
        2: 3,  # Potato -> Potato Scab
        3: 4,  # Apple -> Apple Scab
        4: 5,  # Corn -> Corn Rust
        5: 2,  # Bell Pepper -> Late Blight (simulating a detection)
    }
    
    # Default to first disease if plant type not found in the map
    return plant_to_disease_map.get(int(plant_type_id), 1)
